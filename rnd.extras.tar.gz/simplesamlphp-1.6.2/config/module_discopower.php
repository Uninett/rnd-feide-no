<?php
/* 
 * Configuration for the DiscoPower module.
 * 
 * $Id: $
 */

$config = array (

	// Which tab should be set as default. 0 is the first tab.
	'defaulttab' => 0,
	
	/*
	 * List a set of tags (Tabs) that should be listed in a specific order.
	 * All other available tabs will be listed after the ones specified below.
	 */
	'taborder' => array('norway', 'kalmar', 'ireland', 'greece', 'spain', 'portugal', 'edugain', 'experimental'),

);

?>
