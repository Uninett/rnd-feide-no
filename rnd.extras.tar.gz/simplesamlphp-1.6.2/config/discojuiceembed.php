<?php

/**
 * This is the configuration file for the Auth MemCookie example.
 */

$config = array(
	'target' => 'a.signin',
	'discojuice.options' => array(
		"title"=> 'Sign in to <strong>Feide RnD</strong>',
		"subtitle"=> "Select your Provider",
		
// 		'textSearch' => 'søk etter noe...',
// 		'textHelp' => 'Finner du ikke en innnloggsingstjener du kjenner?',
// 		'textHelpMore' => 'Let mer...',
		
//		"metadata" => 'http://misc.rnd.feide.no/discojuicejson/index.php?callback=?',
		
		"disco" => array(
			"spentityid" =>  "https://rnd.feide.no/simplesaml/module.php/saml/sp/metadata.php/saml",
			"url" => "https://rndfeide.no/simplesaml/module.php/discojuice/discojuiceDiscoveryResponse.html?",
			"stores" => array(
				'http://discojuice.bridge.uninett.no/central.php',
				'https://disco.uninett.no/',
				'https://foodle.feide.no/simplesaml/module.php/discopower/disco.php',
				'https://kalmar2.org/simplesaml/module.php/discopower/disco.php'
			),
			"subIDstores" => array(
				'https://idp.feide.no' => 'https://idp.feide.no/simplesaml/module.php/feide/getOrg.php'
			),
			"subIDwritableStores" => array(
				'https://idp.feide.no' => 'https://idp.feide.no/simplesaml/module.php/feide/preselectOrg.php?ReturnTo=http://discojuice.bridge.uninett.no/simplesaml/module.php/discojuice/discojuice/discojuiceDiscoveryResponse.html&HomeOrg='
			),
 			'writableStore' => 'http://disco.uninett.no'
		),
		
		"always"=> true,
		"overlay"=> true,
		"cookie"=> true,
		"type"=> false,
		"country"=> true,
		"location"=> true,
		"debug.weight" => false,
	),
	
	"callback" => " function(e) {
	var auth = e.auth || null;
	var returnto = window.location.href || 'https://rnd.feide.no';
	switch(auth) {
	
		case 'saml':
		default:
			window.location = 'https://rnd.feide.no/simplesaml/module.php/core/as_login.php?AuthId=saml&ReturnTo=' + escape(returnto) + '&saml:idp=' + escape(e.entityID);
		break;							
			
	}
}

	"
	

);