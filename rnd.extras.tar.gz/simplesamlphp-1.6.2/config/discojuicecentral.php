<?php

/**
 * This is the configuration file for the Auth MemCookie example.
 */

$config = array(

	'acl' => array(
		'simplesamlphp.org', 'foodl.org', 'dev.andreas.feide.no',
	),
	
	'discojuice.options' => array(
		"title"=> 'Sign in to <strong>Feide RnD</strong>',
		"subtitle"=> "Select your Provider",
		
		"always"=> true,
		"overlay"=> true,
		"cookie"=> true,
		"type"=> false,
		"country"=> true,
		"location"=> true,
		"debug.weight" => false,
	),
	
	

);