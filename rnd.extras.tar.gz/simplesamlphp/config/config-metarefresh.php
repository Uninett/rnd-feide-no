<?php

$config = array(

	'sets' => array(

		/*
		 * Kalmar Union Metadata retrieval
		 */
		'kalmar' => array(
			'cron'		=> array('hourly'),
			'sources'	=> array(
				array(
					'src' => 'https://kalmar2.org/simplesaml/module.php/aggregator/?id=kalmarcentral&set=saml2',
					'validateFingerprint' => '59:1D:4B:46:70:46:3E:ED:A9:1F:CC:81:6D:C0:AF:2A:09:2A:A8:01',
					'template' => array(
						'tags'	=> array('kalmar'),
						'authproc' => array(
							51 => array('class' => 'core:AttributeMap', 'oid2name'),
						),
					),
				),
			),
			'maxCache' 		=> 60*60*24*4, // Maximum 4 days cache time.
			'maxDuration' 	=> 60*60*24*10, // Maximum 10 days duration on ValidUntil.
			'outputDir' 	=> 'metadata/metadata-kalmar-consuming/',

			/*
			 * Which output format the metadata should be saved as.
			 * Can be 'flatfile' or 'serialize'. 'flatfile' is the default.
			 */
			'outputFormat' => 'serialize',

		),
	),
);



