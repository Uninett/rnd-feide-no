<?php
/* 
 * Configuration for the kalmarlist module.
 * 
 * $Id: $
 */

$config = array (

	'allowedTags' => array('prod'),
	'defaultTag' => 'prod',
	
	'dirs' => array(
		'prod' => 'metadata/metadata-kalmar-consuming',
	)

);

