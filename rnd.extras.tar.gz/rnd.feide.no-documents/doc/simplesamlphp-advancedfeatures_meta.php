<?php

$metadata = array(
	'' 		=> 'Corresponding to latest version of simpleSAMLphp (from trunk)',
	'1.5' 	=> 'Corresponding to simpleSAMLphp v1.5',
	'1.3' 	=> 'Corresponding to simpleSAMLphp v1.3',
	'1.1' 	=> 'Corresponding to simpleSAMLphp v1.1',
	'1.0' 	=> 'Corresponding to simpleSAMLphp v1.0',
)

?>