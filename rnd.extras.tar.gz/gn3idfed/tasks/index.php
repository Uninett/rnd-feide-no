<?php
require('lib.php');

require('lib/markdown.php');


$rtm = new RTM('cda086fb8642ac0e8081f06263c4f341','f244a2cef039b2f3');


function date_diff($secondsago) {
	
#		echo 'comparing ' . $secondsago;
#		return $secondsago . ' seconds';

	if (is_null($secondsago)) return 'NA';

	$nseconds = abs($secondsago); // Number of seconds between the two dates
	
	$ndays = round($nseconds / 86400); // One day has 86400 seconds
	$nseconds = $nseconds % 86400; // The remainder from the operation
	$nhours = round($nseconds / 3600); // One hour has 3600 seconds
	$nseconds = $nseconds % 3600;
	$nminutes = round($nseconds / 60); // One minute has 60 seconds, duh!
	$nseconds = $nseconds % 60;

	if ($ndays > 0) 
		return $ndays . " days";
	elseif ($nhours > 0) 
		return $nhours . "h " . $nminutes . "m";
	elseif ($nminutes > 0) 
		return $nminutes . " min";
	else 
		return $nseconds . " sec";
} 

function rtm_auth() {

	global $rtm;
	$url = $rtm->genAuthURL('read');
	echo '<p>Auth URL <pre>' . $url . '</pre>'; 
	echo '<a href="' . $url . '">link</a>';
	exit;
}
function rtm_gettoken($frob) {
	global $rtm;
	$url = $rtm->genAuthURL('read');
	$ret = $rtm->doMethod('auth','getToken', array('frob' => $frob));
	$xml = new SimpleXMLElement($ret);
	$token = (string) $xml->auth->token;
	print_r($ret);
	exit;
}

function rtm_getLists($token) {
	global $rtm;
	$args = array(
		'auth_token'	=> $token,
		'format' => 'json',
// 		'list_id' => '11406041',
//		'filter' => 'Strømmåler avlesning',
	);
	$ret = json_decode($rtm->doMethod('lists','getList', $args), TRUE);
	
#	echo '<pre>'; print_r($ret); exit;
	$res = array();
	
	header('Content-type: text/plain; charset=utf-8');	
	
	foreach($ret['rsp']['lists']['list'] AS $list) {
		$res[$list->id] = $list['name'];
		echo $list['name'] . ' [' . $list['id'] . ']' . "\n";
	}

}

function rtm_sl($token) {
	global $rtm;
	$args = array(
		'auth_token'	=> $token,
		'format' => 'json',
 		'list_id' => '16063969',
//		'filter' => 'Strømmåler avlesning',
	);
	$ret = json_decode($rtm->doMethod('tasks','getList', $args), TRUE);
	return $ret['rsp']['tasks']['list']['taskseries'];

}

$config = array(
	'frob' => '1def65e2090e1de7aa98dee64e9b3262d5b669bb',
	'token' => '6581da3a86776c40e143df49bb0743d44eff225c',
// 	'list_id' => '16063969',
// 	'filter' => 'Strøm avlesning',
// 	'text' => 'Strømforbruk i Jan Voigts vei 10',
);


#rtm_auth(); 
#rtm_gettoken($aconfig['frob']);
#rtm_getLists($config['token']);
#

$res = rtm_sl($config['token']);


$structured = array(
	'hot' => array(),
	'planned' => array(),
	'ideas' => array(),
	'completed' => array(),
	'onhold' => array(),
);
$structuredMeta = array(
	'hot' => array('header' => 'Active', 'descr' => 'Active tasks that are currently beeing worked on, and in progress.'),
	'planned' => array('header' => 'Planned', 'descr' => 'Planned tasks that have not yet started.'),
	'ideas' => array('header' => 'Ideas', 'descr' => 'Ideas, that currently is not accepted as part of the planned activity. In planning phase.'),
	'completed' => array('header' => 'Completed', 'descr' => 'Completed tasks. Not being worked on actively.'),
	'onhold' => array('header' => 'On Hold', 'descr' => 'Tasks that are put on hold or rejected for some reason.'),
);
foreach($res AS $entry) {
	if (!empty($entry['task']['completed'])) {
		$structured['completed'][] = $entry;
	} elseif($entry['task']['priority'] == 1) {
		$structured['hot'][] = $entry;
	} elseif($entry['task']['priority'] == 2) {
		$structured['planned'][] = $entry;
	} elseif($entry['task']['priority'] == 3) {
		$structured['onhold'][] = $entry;
	} else {
		$structured['ideas'][] = $entry;
	}
	
##	}
}

// foreach($structured AS $k => $l) {
// 	echo '<h2>' . $k . '</h2><ul>';
// 	foreach($l AS $e) {
// 		echo '<li>' . $e->name . ' (' . $e->task->priority. ')</li>';
// 		echo '<li><pre>';
// 		print_r($e);
// 		echo '</pre></li>';
// 	}
// 	echo '</ul>';
// }


#	echo '<pre>'; print_r($structured); exit;





include('template.php');