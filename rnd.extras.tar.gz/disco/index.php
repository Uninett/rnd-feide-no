<?php

$acl = array(
	'http://ulx.foodl.org/res/discojuice/ulxDiscoveryResponse.html',
	'https://bridge.feide.no/discojuice/discojuiceDiscoveryResponse.html',
);

if (isset($_REQUEST['IdPentityID'])) {
	setcookie("_IdP", $_REQUEST['IdPentityID'], time()+3600*24*365*10, "/disco/");
}

if (isset($_COOKIE['_IdP']) && in_array($_REQUEST['return'], $acl) ) {
	$url = $_REQUEST['return'] . '?' . urlencode($_REQUEST['returnIDParam']) . '=' . urlencode($_COOKIE['_IdP']);
	header('Location: ' . $url);
	exit;
}



?>



<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>IdP Discovery Service</title>
</head>

<body>

<?php

echo '<p>chosen idp was ' . $_COOKIE['_IdP'];
echo '<p>return to ' . $_REQUEST['return'];


?>	
</body>
</html>
