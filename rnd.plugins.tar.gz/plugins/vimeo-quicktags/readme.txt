=== vimeo quicktag ===
Contributors: denzel_chia
Donate link: http://denzeldesigns.com
Author link: http://denzeldesigns.com
Tags:vimeo-quicktag, vimeo, quicktag, embed video, embed vimeo video
Requires at least: 2.6
Tested up to: 3.0.1
Stable tag:2.0

== Description ==

Allows Vimeo video embed to be viewed in iPad, iPhone, and iPod Touch.
This plugin interprets its vimeo shortcode to produce the latest vimeo iframe embed code.

== Changelog ==

= 2.0 =

1. Rewrited plugin to produce Vimeo iframe embed code.
2. Plugin inserts vimeo video shortcode, instead of flash embed code.
3. Plugin interprets vimeo shortcode, into Vimeo iframe embed code.
4. Added preview video feature. 

= 1.2 =

1. Changed plugin path to defined WP_PLUGINS_URL

2. Added White Colour.

== Installation ==


1. Upload `vimeo quicktag` to the `/wp-content/plugins/` directory and unzip
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Click refresh if vimeo quicktag does not show after activation.


== Screenshots ==

1. Vimeo Quicktag dialog window


