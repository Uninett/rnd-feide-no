<?php
/*
Plugin Name: External Document Resolve
Plugin URI: http://rnd.feide.no
Description: Will resolve a document ID to a local file.
Version: 0.1
Author: Andreas Åkre Solberg
Author URI: http://rnd.feide.no
*/



//Shortcode [catlist parameter="value"]
function document_func($atts, $content=null) {
	$atts = shortcode_atts(array(
			'id' => NULL,
			'toc' => 'yes',
		), $atts);
	return resolveDocument($atts);
}

add_shortcode('document', 'document_func');

function resolveDocument($atts){

	if (empty($atts['id'])) return 'Document could not be resolved, be cause of missing Identifier.';

	$id = $atts['id'];
		
	$prefix = '/www/rnd.feide.no/wordpress/doc/';
	$urlprefix = '/doc/';
	

	$metafile = $prefix . $id . '_meta.php';
	$selectedfile = $id . '.';
	
	$text = '';
	
	if (preg_match('/^git\/(.*)$/', $atts['id'], $matches)) {
		
		$url = 'https://github.com/andreassolberg/documents/raw/master/' . $matches[1]. '.md';
		
#		print_r($matches);
		
#		echo 'URL IS : ' . $url;
		
		$file = file_get_contents($url);
		
		// require_once(dirname(__FILE__) . '/markdown/markdown.php');
		// require_once('/inc/markdown/AMD.php');
		
		$m = new AMD($file);
		$m->removeH1();
		$html = $m->getHTML(($atts['toc'] == 'yes'));
		
// 		$html = str_replace('src="resources/', 'src="/doc/resources/', $html);
// 		$html = str_replace('src="res/', 'src="/doc/rnd-docs/res/', $html);
		
		$text .= '<div class="article">';
		$text .= $html;
		$text .= '</div>';
		
		return $text;
	}
	

	if (file_exists($metafile)) {
	
		include($metafile);
		$text .= '<h3>Alternative versions available of this document</h3><dl>';
		foreach ($metadata AS $key => $version) {
		
			if (empty($_REQUEST['version']) && $key == '' ) {
				$text .= '<dt>latest version (<i>selected</i>)</dt><dd>' . $version . '</dd>';
				
			} elseif ($_REQUEST['version'] === $key) {
				$text .= '<dt>version ' . $key . ' (<i>selected</i>)</dt><dd>' . $version . '</dd>';
				$selectedfile = $node->field_documentid[0]['value'] . '_' . $key . '.';
			} elseif ($key == '') {
				$text .= '<dt>latest version</dt><dd><a href="?">' . $version . '</a></dd>';
				
			} else {
				$text .= '<dt>version ' . $key . '</dt><dd><a href="?version=' . $key . '">' . $version . '</a></dd>';
			}
		
		}
		$text .= '</dl>';
	
	} else {

	}
	#echo 'file is: '.  $prefix . $selectedfile;

	if (file_exists($prefix . $selectedfile . 'pdf')) {
		$text .= '<h3>Download document</h3>';
		$text .= '<ul><li><a href="' . $urlprefix . $selectedfile . 'pdf">Download document in PDF format</li></ul></a>';
	}
	
	if (file_exists($prefix . $selectedfile . 'html')) {

		$file = file_get_contents($prefix . $selectedfile . 'html');

#			$file = preg_replace('/^.*?<body>/ms', '', $file);
#			$file = preg_replace('|</body>.*$|ms', '', $file);

		$file = preg_replace('|<h1[^>]*>.*</h1>|m', '', $file);

		if(preg_match('/<body>/', $file)) {
			$filesplit = split('<body>', $file);
			$nextsplit = split('</body>', $filesplit[1]);
			$filenew = $nextsplit[0];
		} else {
			$filenew = $file;
		}

		$filenew = str_replace('src="resources/', 'src="/doc/resources/', $filenew);
		$filenew = str_replace('src="res/', 'src="/doc/rnddocs/res/', $filenew);

		$text .= $file; 
		
	} elseif(file_exists($prefix . $selectedfile . 'txt')) {

		$file = file_get_contents($prefix . $selectedfile . 'txt');
		
		// require_once(dirname(__FILE__) . '/markdown/markdown.php');
		// require_once('/inc/markdown/AMD.php');
		
		$m = new AMD($file);
		$m->removeH1();
		$html = $m->getHTML(($atts['toc'] == 'yes'));
		$html = str_replace('src="resources/', 'src="/doc/resources/', $html);
		$html = str_replace('src="res/', 'src="/doc/rnd-docs/res/', $html);
		
		$text .= '<div class="article">';
		$text .= $html;
		$text .= '</div>';
	
	}
	
	
	#$text .= 'Resolved **document** with id [' . $atts['id'] . ']';
	
	
	return $text;
	
}




class AMD {
	
	private $doc;
	private $docraw = NULL;
	function __construct($doc) {
		$this->docraw = $doc;
		$this->doc = Markdown($doc);
	}
	
	public function getHTML($usetoc = TRUE) {
		$toc = '';
		if ($usetoc) $toc = '<h2>Table of Contents</h2>' . $this->toc();
		$html = $this->doc;
		$html = preg_replace('/<!-- {{TOC}} -->/', $toc, $html);
		
		return $html;
	}
	
	public function getFirst($no) {
		$this->doc = Markdown(substr($this->docraw, 0, $no) . '...');
	} 
	
	public function removeH1() {
		$this->doc = preg_replace('|<h1>(.*?)</h1>|', '', $this->doc);
	}
	
	public function hideHeaders() {
		$this->doc = preg_replace('|<h[1-6]>|', '<p><strong>', $this->doc);
		$this->doc = preg_replace('|</h[1-6]>|', '</strong></p>', $this->doc);
	}
	
	
	function tocr(&$s, $level = 2) {
		$headersOnLevel = array();
		$previous = NULL;
		while(!empty($s) && $s[0][1] >= $level ) {

			if ($s[0][1] == $level) {

				$headersOnLevel[$s[0][2]] = NULL;
				array_shift($s);
			} else {

				$headersOnLevel[reset(array_reverse(array_keys($headersOnLevel)))] = $this->tocr($s, $level+1);
			}

		}
		return $headersOnLevel;			
	}

	static function tocprint(&$toc, $level = 1) {
	#	echo '<pre>'; print_r($toc); exit;
		
		$html = '<ul>';
		
		while (count($toc) > 0) {
			
			$tocEntry = array_shift($toc);


			if ($tocEntry['level'] >= $level) {	
				$html .= '<li><a href="#' . $tocEntry['anchor'] . '">' . $tocEntry['section'] . ' ' . $tocEntry['title'] . '</a>';
			}
			
			if($toc[0]['level'] > $level) {
				$html .= self::tocprint($toc, $level+1);
			}
			
			if ($toc[0]['level'] < $level) {
				$html .= '</li></ul>';
				return $html;
			}
			
			$html .= '</li>';
		}
		$html .= '</ul>';
		return $html;
	}
	
	public static function anchor($matches) {
		global $counter; $id = ++$counter; global $sect;
		global $toc;
		
		$level = count($sect);
		$h = $matches[1] - 1;
					
		#echo '<p>Comparing h' . $h . ' to level ' . $level;
		
		if ($h > $level) {
			$sect[] = 1;
			#echo ' - Dive';
		} elseif($h < $level) {
			#echo ' - Lift';
			array_pop($sect);
			$sect[count($sect)-1]++;
		} else {
			#echo ' - Increase';
			$sect[count($sect)-1]++;
		}
		#echo '--- '  . join('.', $sect);
		
		$tocNEW = array(
			'section' => join('.', $sect),
			'title' => $matches[2],
			'anchor' => 'section_' . join('_', $sect),
			'level' => count($sect),
		);
		$toc[] = $tocNEW;
		
		return '<h' . $matches[1] . '><a name="' . $tocNEW['anchor'] . '" id="' . $tocNEW['anchor'] . '" />' . 
			$tocNEW['section'] . ' ' . $tocNEW['title'] . '</a></h' . $matches[1] . '>';
	}

	function toc() {
		preg_match_all('|<h([2-6])[^>]*>(.*)</h[1-6]>|m', $this->doc, $matches, PREG_SET_ORDER);	
		
		global $counter; $counter = 0;
		global $sect; $sect = array(0);
		global $toc;
		

		
		$this->doc = preg_replace_callback("|<h([2-6])[^>]*>(.*)</h[1-6]>|m", array('AMD', 'anchor'), $this->doc);
		
		
		#$toc = $this->tocr($matches);
		$counter = 0;
		return '<div id="toc">' . self::tocprint($toc) . '</div>';
	}
	
	
}


?>